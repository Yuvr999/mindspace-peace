'use client';

import { useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { ArrowLeft, Heart, Loader2, UserCheck, Clock } from 'lucide-react';
import Link from 'next/link';
import SOSButton from '@/components/SOSButton';

export default function MatchPage() {
    const [userId, setUserId] = useState<string | null>(null);
    const [loading, setLoading] = useState(true);
    const [matching, setMatching] = useState(false);
    const [matched, setMatched] = useState(false);
    const [waitTime, setWaitTime] = useState(0);
    const supabase = createClient();

    useEffect(() => {
        initializeUser();
    }, []);

    useEffect(() => {
        if (matching) {
            const interval = setInterval(() => {
                setWaitTime((prev) => prev + 1);
            }, 1000);
            return () => clearInterval(interval);
        }
    }, [matching]);

    const initializeUser = async () => {
        try {
            const { data: { session } } = await supabase.auth.getSession();

            if (session?.user) {
                setUserId(session.user.id);
            } else {
                const { data, error } = await supabase.auth.signInAnonymously();
                if (error) throw error;
                setUserId(data.user?.id || null);
            }

            setLoading(false);
        } catch (error) {
            console.error('Error initializing user:', error);
            setLoading(false);
        }
    };

    const findCounselor = async () => {
        if (!userId) return;

        setMatching(true);
        setWaitTime(0);

        // Simulate matching delay for demonstration
        setTimeout(() => {
            setMatched(true);
            setMatching(false);
        }, 3000);
    };

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-emerald-900/20 to-slate-900">
                <Loader2 className="w-8 h-8 animate-spin text-emerald-400" />
            </div>
        );
    }

    if (matched) {
        return (
            <main className="min-h-screen relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-emerald-900/20 to-slate-900" />

                <div className="relative z-10 max-w-2xl mx-auto px-6 py-16 text-center">
                    <div className="mb-8 relative">
                        <div className="absolute inset-0 bg-emerald-500/20 rounded-full blur-3xl animate-pulse" />
                        <UserCheck className="w-24 h-24 text-emerald-400 mx-auto relative" />
                    </div>

                    <h1 className="text-4xl font-bold mb-4">Match Found! 🎉</h1>
                    <p className="text-slate-400 mb-8">
                        You&apos;ve been matched with a trained peer counselor. They&apos;ll reach out to you shortly via the chat interface.
                    </p>

                    <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6 mb-8">
                        <h3 className="font-semibold mb-3">What to Expect:</h3>
                        <ul className="text-left text-slate-400 space-y-2">
                            <li className="flex gap-2">
                                <span className="text-emerald-400">•</span>
                                <span>Your counselor is a trained student volunteer</span>
                            </li>
                            <li className="flex gap-2">
                                <span className="text-emerald-400">•</span>
                                <span>Sessions are completely anonymous and confidential</span>
                            </li>
                            <li className="flex gap-2">
                                <span className="text-emerald-400">•</span>
                                <span>All conversation history self-destructs after 24 hours</span>
                            </li>
                            <li className="flex gap-2">
                                <span className="text-emerald-400">•</span>
                                <span>You can end the session at any time</span>
                            </li>
                        </ul>
                    </div>

                    <Link
                        href="/chat"
                        className="inline-block px-8 py-4 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 rounded-xl font-semibold transition-all hover:scale-105"
                    >
                        Go to Chat
                    </Link>
                </div>

                <SOSButton />
            </main>
        );
    }

    if (matching) {
        return (
            <main className="min-h-screen relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-emerald-900/20 to-slate-900" />
                <div className="absolute top-20 left-10 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl animate-pulse" />

                <div className="relative z-10 max-w-2xl mx-auto px-6 py-16 text-center">
                    <Loader2 className="w-16 h-16 text-emerald-400 mx-auto mb-6 animate-spin" />
                    <h1 className="text-4xl font-bold mb-4">Finding Your Counselor...</h1>
                    <p className="text-slate-400 mb-8">
                        We&apos;re matching you with an available peer counselor. This usually takes less than a minute.
                    </p>

                    <div className="flex items-center justify-center gap-2 text-slate-500 mb-8">
                        <Clock className="w-4 h-4" />
                        <span>{waitTime}s</span>
                    </div>

                    <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6">
                        <p className="text-sm text-slate-400">
                            <span className="font-semibold text-slate-300">Tip:</span> While you wait, take a few deep breaths. You&apos;re taking an important step toward feeling better.
                        </p>
                    </div>
                </div>

                <SOSButton />
            </main>
        );
    }

    return (
        <main className="min-h-screen relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-emerald-900/20 to-slate-900" />
            <div className="absolute top-20 right-10 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl animate-pulse" />

            <div className="relative z-10 max-w-2xl mx-auto px-6 py-16 text-center">
                <Link
                    href="/"
                    className="inline-flex items-center gap-2 text-slate-400 hover:text-emerald-400 transition-colors mb-8"
                >
                    <ArrowLeft className="w-4 h-4" />
                    Back to Home
                </Link>

                <Heart className="w-16 h-16 text-emerald-400 mx-auto mb-6" />
                <h1 className="text-4xl font-bold mb-4">Find a Peer Counselor</h1>
                <p className="text-slate-400 mb-8">
                    Connect with a trained student counselor for guided, empathetic support. All sessions are anonymous and completely confidential.
                </p>

                <div className="grid md:grid-cols-2 gap-4 mb-8">
                    <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6 text-left">
                        <h3 className="font-semibold mb-2 flex items-center gap-2">
                            <UserCheck className="w-5 h-5 text-emerald-400" />
                            Trained Volunteers
                        </h3>
                        <p className="text-sm text-slate-400">
                            Our peer counselors are specially trained students who understand what you&apos;re going through
                        </p>
                    </div>

                    <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6 text-left">
                        <h3 className="font-semibold mb-2 flex items-center gap-2">
                            <Heart className="w-5 h-5 text-emerald-400" />
                            Compassionate Care
                        </h3>
                        <p className="text-sm text-slate-400">
                            Receive empathy, active listening, and evidence-based coping strategies
                        </p>
                    </div>
                </div>

                <button
                    onClick={findCounselor}
                    className="px-8 py-4 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 rounded-xl font-semibold transition-all hover:scale-105 flex items-center gap-2 mx-auto"
                >
                    Find a Counselor
                </button>

                <p className="text-xs text-slate-500 mt-6">
                    Average wait time: &lt; 2 minutes
                </p>
            </div>

            <SOSButton />
        </main>
    );
}
