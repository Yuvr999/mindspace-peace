'use client';

import { useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { ArrowLeft, Send, Loader2, Users } from 'lucide-react';
import Link from 'next/link';
import SOSButton from '@/components/SOSButton';

interface Message {
    id: string;
    content: string;
    sender_id: string;
    created_at: string;
}

export default function ChatPage() {
    const [userId, setUserId] = useState<string | null>(null);
    const [roomId, setRoomId] = useState<string | null>(null);
    const [messages, setMessages] = useState<Message[]>([]);
    const [newMessage, setNewMessage] = useState('');
    const [loading, setLoading] = useState(true);
    const [matching, setMatching] = useState(false);
    const supabase = createClient();

    useEffect(() => {
        initializeUser();
    }, []);

    const initializeUser = async () => {
        try {
            // Try to get existing session
            const { data: { session } } = await supabase.auth.getSession();

            if (session?.user) {
                setUserId(session.user.id);
            } else {
                // Create anonymous user
                const { data, error } = await supabase.auth.signInAnonymously();
                if (error) throw error;
                setUserId(data.user?.id || null);
            }

            setLoading(false);
        } catch (error) {
            console.error('Error initializing user:', error);
            setLoading(false);
        }
    };

    const findMatch = async () => {
        if (!userId) return;

        setMatching(true);
        try {
            // Look for waiting rooms
            const { data: waitingRooms } = await supabase
                .from('rooms')
                .select('*')
                .eq('status', 'waiting')
                .limit(1)
                .single();

            if (waitingRooms) {
                // Join existing room
                await supabase
                    .from('room_participants')
                    .insert({ room_id: waitingRooms.id, user_id: userId });

                // Update room status
                await supabase
                    .from('rooms')
                    .update({ status: 'active' })
                    .eq('id', waitingRooms.id);

                setRoomId(waitingRooms.id);
                subscribeToMessages(waitingRooms.id);
            } else {
                // Create new room
                const { data: newRoom } = await supabase
                    .from('rooms')
                    .insert({ status: 'waiting' })
                    .select()
                    .single();

                if (newRoom) {
                    await supabase
                        .from('room_participants')
                        .insert({ room_id: newRoom.id, user_id: userId });

                    setRoomId(newRoom.id);
                    subscribeToMessages(newRoom.id);
                }
            }
        } catch (error) {
            console.error('Error finding match:', error);
        }
        setMatching(false);
    };

    const subscribeToMessages = (room: string) => {
        supabase
            .from('messages')
            .select('*')
            .eq('room_id', room)
            .order('created_at', { ascending: true })
            .then(({ data }) => {
                if (data) setMessages(data);
            });

        const channel = supabase
            .channel(`room:${room}`)
            .on(
                'postgres_changes',
                {
                    event: 'INSERT',
                    schema: 'public',
                    table: 'messages',
                    filter: `room_id=eq.${room}`,
                },
                (payload) => {
                    setMessages((prev) => [...prev, payload.new as Message]);
                }
            )
            .subscribe();

        return () => {
            supabase.removeChannel(channel);
        };
    };

    const sendMessage = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newMessage.trim() || !roomId || !userId) return;

        try {
            const expiresAt = new Date();
            expiresAt.setHours(expiresAt.getHours() + 24);

            await supabase.from('messages').insert({
                room_id: roomId,
                sender_id: userId,
                content: newMessage,
                expires_at: expiresAt.toISOString(),
            });

            setNewMessage('');
        } catch (error) {
            console.error('Error sending message:', error);
        }
    };

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-teal-900/20 to-slate-900">
                <Loader2 className="w-8 h-8 animate-spin text-teal-400" />
            </div>
        );
    }

    if (!roomId) {
        return (
            <main className="min-h-screen relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-teal-900/20 to-slate-900" />
                <div className="absolute top-20 left-10 w-72 h-72 bg-teal-500/10 rounded-full blur-3xl animate-pulse" />

                <div className="relative z-10 max-w-2xl mx-auto px-6 py-16 text-center">
                    <Link
                        href="/"
                        className="inline-flex items-center gap-2 text-slate-400 hover:text-teal-400 transition-colors mb-8"
                    >
                        <ArrowLeft className="w-4 h-4" />
                        Back to Home
                    </Link>

                    <Users className="w-16 h-16 text-teal-400 mx-auto mb-6" />
                    <h1 className="text-4xl font-bold mb-4">Anonymous Peer Chat</h1>
                    <p className="text-slate-400 mb-8">
                        Connect with another student for anonymous peer support. Your conversation is private and will self-destruct after 24 hours.
                    </p>

                    <button
                        onClick={findMatch}
                        disabled={matching}
                        className="px-8 py-4 bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600 rounded-xl font-semibold transition-all hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 mx-auto"
                    >
                        {matching ? (
                            <>
                                <Loader2 className="w-5 h-5 animate-spin" />
                                Finding a peer...
                            </>
                        ) : (
                            'Find a Peer'
                        )}
                    </button>
                </div>

                <SOSButton />
            </main>
        );
    }

    return (
        <main className="min-h-screen bg-gradient-to-br from-slate-900 via-teal-900/20 to-slate-900 flex flex-col">
            {/* Header */}
            <div className="border-b border-slate-700/50 backdrop-blur-sm bg-slate-900/50 p-4">
                <div className="max-w-4xl mx-auto flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <div className="w-3 h-3 bg-emerald-400 rounded-full animate-pulse" />
                        <span className="font-semibold">Connected to Peer</span>
                    </div>
                    <Link href="/" className="text-sm text-slate-400 hover:text-teal-400 transition-colors">
                        Leave Chat
                    </Link>
                </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-6 max-w-4xl mx-auto w-full">
                <div className="space-y-4">
                    {messages.length === 0 && (
                        <div className="text-center text-slate-400 py-8">
                            No messages yet. Say hello! 👋
                        </div>
                    )}

                    {messages.map((msg) => (
                        <div
                            key={msg.id}
                            className={`flex ${msg.sender_id === userId ? 'justify-end' : 'justify-start'}`}
                        >
                            <div
                                className={`max-w-sm px-4 py-3 rounded-2xl ${msg.sender_id === userId
                                        ? 'bg-gradient-to-r from-teal-500 to-emerald-500 text-white'
                                        : 'bg-slate-800 border border-slate-700'
                                    }`}
                            >
                                <p className="break-words">{msg.content}</p>
                                <p className="text-xs opacity-70 mt-1">
                                    {new Date(msg.created_at).toLocaleTimeString()}
                                </p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {/* Input */}
            <div className="border-t border-slate-700/50 backdrop-blur-sm bg-slate-900/50 p-4">
                <form onSubmit={sendMessage} className="max-w-4xl mx-auto flex gap-3">
                    <input
                        type="text"
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        placeholder="Type your message..."
                        className="flex-1 px-4 py-3 rounded-xl bg-slate-800 border border-slate-700 focus:border-teal-500 focus:outline-none transition-colors"
                    />
                    <button
                        type="submit"
                        disabled={!newMessage.trim()}
                        className="px-6 py-3 bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600 rounded-xl font-semibold transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                    >
                        <Send className="w-5 h-5" />
                    </button>
                </form>
            </div>

            <SOSButton />
        </main>
    );
}
