# Setup Guide for MindSpace

Follow these steps to get the mental health platform running:

## 1. Supabase Setup (Required for Chat/Matching)

### Create Supabase Project
1. Go to [supabase.com](https://supabase.com) and sign up/login
2. Click "New Project"
3. Choose a name, database password, and region
4. Wait for the project to be created (~2 minutes)

### Run the Database Schema
1. In your Supabase dashboard, navigate to **SQL Editor** (left sidebar)
2. Click "New Query"
3. Open the file: `supabase/schema.sql` in your code editor
4. Copy ALL the contents
5. Paste into the Supabase SQL Editor
6. Click "Run" (or press Ctrl+Enter)
7. You should see "Success. No rows returned" - this is correct!

### Get Your Environment Variables
1. In Supabase dashboard, go to **Project Settings** (gear icon in sidebar)
2. Click **API** in the left menu
3. Copy the following:
   - **Project URL** (under "Project URL")
   - **anon public** key (under "Project API keys")

### Configure Your App
1. In your project root, create a file named `.env.local`
2. Add the following (replace with your actual values):
   ```env
   NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key-here
   ```
3. Save the file

## 2. Run the Application

```bash
# If dev server is not running, start it:
npm run dev
```

The app will be available at **http://localhost:3000**

## 3. Test the Features

### Landing Page
- Visit http://localhost:3000
- You should see the beautiful hero section

### Chat Feature
1. Open http://localhost:3000/chat in TWO different browsers (or one normal + one incognito)
2. Click "Find a Peer" on both
3. They should match and you can send messages between them!

### Counselor Matching
- Visit http://localhost:3000/match
- Click "Find a Counselor" and wait for the animation

### Resources
- Visit http://localhost:3000/resources
- Browse mental health resources

### SOS Button
- Click the red floating button on any page
- Emergency resources modal will appear

## Troubleshooting

**Chat not working?**
- Make sure you've set up Supabase and added `.env.local`
- Restart the dev server after adding environment variables
- Check browser console for errors

**Supabase errors?**
- Verify the SQL schema was run successfully
- Check that your environment variables are correct
- Make sure RLS policies are enabled

Enjoy building a safer mental health platform! 🌟
