-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- Profiles: Anonymous users
create table profiles (
  id uuid references auth.users on delete cascade primary key,
  avatar_seed text, -- For generating random avatars (e.g., Dicebear)
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Rooms: Chat sessions
create table rooms (
  id uuid default uuid_generate_v4() primary key,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  status text check (status in ('waiting', 'active', 'closed')) default 'waiting'
);

-- Room Participants: Linking users into rooms
create table room_participants (
  room_id uuid references rooms(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  joined_at timestamp with time zone default timezone('utc'::text, now()) not null,
  primary key (room_id, user_id)
);

-- Messages: Chat content
create table messages (
  id uuid default uuid_generate_v4() primary key,
  room_id uuid references rooms(id) on delete cascade not null,
  sender_id uuid references profiles(id) on delete cascade not null,
  content text not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  expires_at timestamp with time zone -- For self-destruct logic
);

-- SOS Logs: Mock logs for emergency clicks (Anonymous)
create table sos_logs (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references profiles(id) on delete set null,
  lat float,
  long float,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Resources: Mental health content
create table resources (
  id uuid default uuid_generate_v4() primary key,
  title text not null,
  description text,
  url text,
  category text,
  tags text[],
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- RLS Policies
alter table profiles enable row level security;
alter table rooms enable row level security;
alter table room_participants enable row level security;
alter table messages enable row level security;
alter table sos_logs enable row level security;
alter table resources enable row level security;

-- Profiles: Users can read/update their own profile
create policy "Users can view own profile" on profiles
  for select using (auth.uid() = id);
create policy "Users can update own profile" on profiles
  for update using (auth.uid() = id);
create policy "Public profiles (for matching)" on profiles
  for select using (true); -- Simplified for MVP, maybe restrict later

-- Rooms: Users can view rooms they are in or if status is waiting (to join)
create policy "Users can view joined rooms" on rooms
  for select using (
    exists (
      select 1 from room_participants
      where room_participants.room_id = rooms.id
      and room_participants.user_id = auth.uid()
    )
    or status = 'waiting'
  );

create policy "Users can insert waiting rooms" on rooms
  for insert with check (status = 'waiting');

create policy "Users can update joined rooms" on rooms
  for update using (
    exists (
      select 1 from room_participants
      where room_participants.room_id = rooms.id
      and room_participants.user_id = auth.uid()
    )
  );

-- Room Participants
create policy "Users can view participants in their rooms" on room_participants
  for select using (
    exists (
      select 1 from room_participants rp
      where rp.room_id = room_participants.room_id
      and rp.user_id = auth.uid()
    )
  );

create policy "Users can join rooms" on room_participants
  for insert with check (auth.uid() = user_id);

-- Messages
create policy "Users can view messages in their rooms" on messages
  for select using (
    exists (
      select 1 from room_participants
      where room_participants.room_id = messages.room_id
      and room_participants.user_id = auth.uid()
    )
  );

create policy "Users can send messages to their rooms" on messages
  for insert with check (
    auth.uid() = sender_id
    and exists (
      select 1 from room_participants
      where room_participants.room_id = messages.room_id
      and room_participants.user_id = auth.uid()
    )
  );

-- Resources: Public read
create policy "Everyone can read resources" on resources
  for select using (true);

-- Functions
-- Function to clean up expired messages
create or replace function delete_expired_messages()
returns void as $$
begin
  delete from messages where expires_at < now();
end;
$$ language plpgsql;

-- Trigger to create profile on signup
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, avatar_seed)
  values (new.id, substr(md5(random()::text), 0, 10));
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
