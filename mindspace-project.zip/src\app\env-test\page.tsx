'use client';

export default function EnvTest() {
    return (
        <div className="p-8">
            <h1 className="text-2xl font-bold mb-4">Environment Variables Test</h1>
            <div className="bg-slate-800 p-4 rounded">
                <p><strong>NEXT_PUBLIC_SUPABASE_URL:</strong></p>
                <p className="text-sm font-mono">{process.env.NEXT_PUBLIC_SUPABASE_URL || 'UNDEFINED'}</p>
                <p className="mt-4"><strong>NEXT_PUBLIC_SUPABASE_ANON_KEY:</strong></p>
                <p className="text-sm font-mono break-all">{process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || 'UNDEFINED'}</p>
            </div>
        </div>
    );
}
