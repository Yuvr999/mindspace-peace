import Link from 'next/link';
import { ArrowLeft, BookOpen, ExternalLink } from 'lucide-react';
import SOSButton from '@/components/SOSButton';

// Mock data - in production, this would come from Supabase
const resources = [
    {
        id: 1,
        title: 'Understanding Anxiety',
        description: 'Learn about anxiety symptoms, triggers, and coping strategies',
        category: 'Mental Health',
        url: 'https://www.nimh.nih.gov/health/topics/anxiety-disorders',
        tags: ['anxiety', 'coping'],
    },
    {
        id: 2,
        title: 'Depression Support Guide',
        description: 'Comprehensive guide to understanding and managing depression',
        category: 'Mental Health',
        url: 'https://www.nimh.nih.gov/health/topics/depression',
        tags: ['depression', 'support'],
    },
    {
        id: 3,
        title: 'Stress Management Techniques',
        description: 'Evidence-based techniques for reducing stress and improving wellbeing',
        category: 'Self-Care',
        url: 'https://www.apa.org/topics/stress',
        tags: ['stress', 'mindfulness'],
    },
    {
        id: 4,
        title: 'Sleep Hygiene Tips',
        description: 'Improve your sleep quality with these science-backed tips',
        category: 'Self-Care',
        url: 'https://www.sleepfoundation.org/sleep-hygiene',
        tags: ['sleep', 'wellness'],
    },
    {
        id: 5,
        title: 'Crisis Hotlines',
        description: 'Immediate help resources for crisis situations',
        category: 'Emergency',
        url: 'https://988lifeline.org/',
        tags: ['crisis', 'emergency'],
    },
    {
        id: 6,
        title: 'Mindfulness Meditation Guide',
        description: 'Begin your mindfulness practice with this beginner-friendly guide',
        category: 'Self-Care',
        url: 'https://www.mindful.org/meditation/mindfulness-getting-started/',
        tags: ['mindfulness', 'meditation'],
    },
];

const categories = ['All', 'Mental Health', 'Self-Care', 'Emergency'];

export default function ResourcesPage() {
    return (
        <main className="min-h-screen relative overflow-hidden">
            {/* Background */}
            <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-blue-900/20 to-slate-900" />
            <div className="absolute top-20 right-10 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse" />

            <div className="relative z-10 max-w-6xl mx-auto px-6 py-8">
                {/* Header */}
                <div className="mb-8">
                    <Link
                        href="/"
                        className="inline-flex items-center gap-2 text-slate-400 hover:text-teal-400 transition-colors mb-4"
                    >
                        <ArrowLeft className="w-4 h-4" />
                        Back to Home
                    </Link>

                    <div className="flex items-center gap-3 mb-4">
                        <BookOpen className="w-10 h-10 text-teal-400" />
                        <h1 className="text-4xl font-bold">Resources Library</h1>
                    </div>
                    <p className="text-slate-400">
                        Curated mental health resources, guides, and support materials
                    </p>
                </div>

                {/* Category Filter */}
                <div className="flex gap-3 mb-8 flex-wrap">
                    {categories.map((cat) => (
                        <button
                            key={cat}
                            className="px-4 py-2 rounded-lg bg-slate-800/50 hover:bg-slate-800 border border-slate-700 hover:border-teal-500/50 transition-all"
                        >
                            {cat}
                        </button>
                    ))}
                </div>

                {/* Resources Grid */}
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {resources.map((resource) => (
                        <a
                            key={resource.id}
                            href={resource.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="group relative"
                        >
                            <div className="absolute inset-0 bg-gradient-to-r from-teal-500/20 to-blue-500/20 rounded-xl blur opacity-0 group-hover:opacity-100 transition-opacity" />
                            <div className="relative bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6 hover:bg-slate-800/70 hover:border-teal-500/50 transition-all h-full flex flex-col">
                                <div className="flex items-start justify-between mb-3">
                                    <span className="text-xs px-2 py-1 rounded-full bg-teal-500/10 text-teal-400 border border-teal-500/20">
                                        {resource.category}
                                    </span>
                                    <ExternalLink className="w-4 h-4 text-slate-500 group-hover:text-teal-400 transition-colors" />
                                </div>

                                <h3 className="text-lg font-semibold mb-2 group-hover:text-teal-400 transition-colors">
                                    {resource.title}
                                </h3>
                                <p className="text-sm text-slate-400 mb-4 flex-grow">
                                    {resource.description}
                                </p>

                                <div className="flex gap-2 flex-wrap">
                                    {resource.tags.map((tag) => (
                                        <span
                                            key={tag}
                                            className="text-xs px-2 py-0.5 rounded bg-slate-700/50 text-slate-400"
                                        >
                                            #{tag}
                                        </span>
                                    ))}
                                </div>
                            </div>
                        </a>
                    ))}
                </div>
            </div>

            <SOSButton />
        </main>
    );
}
