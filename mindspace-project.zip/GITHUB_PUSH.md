# How to Push to GitHub

Your project is now ready to be pushed to GitHub! Follow these steps:

## Step 1: Create a New Repository on GitHub

1. Go to [github.com](https://github.com) and sign in
2. Click the **"+"** icon in the top right, then **"New repository"**
3. Enter repository details:
   - **Repository name**: `mindspace-mental-health` (or any name you prefer)
   - **Description**: "Anonymous peer-to-peer mental health support platform"
   - **Visibility**: Choose Public or Private
   - **DO NOT** check "Initialize with README" (we already have files)
4. Click **"Create repository"**

## Step 2: Push Your Code

After creating the repository, GitHub will show you commands. Use these in your terminal:

```bash
# Add the remote repository (replace YOUR_USERNAME with your GitHub username)
git remote add origin https://github.com/YOUR_USERNAME/mindspace-mental-health.git

# Rename branch to main (if needed)
git branch -M main

# Push your code
git push -u origin main
```

## Alternative: Using GitHub CLI (if installed)

If you have GitHub CLI installed:

```bash
gh repo create mindspace-mental-health --public --source=. --push
```

## Important: Environment Variables

**⚠️ SECURITY NOTE**: Your `.env.local` file (containing Supabase credentials) is already in `.gitignore` and will NOT be pushed to GitHub. This is correct for security!

When deploying or sharing with collaborators, they'll need to create their own `.env.local` file using the template in `SETUP.md`.

## Step 3: Get Your Repository Link

After pushing, your repository will be available at:
```
https://github.com/YOUR_USERNAME/mindspace-mental-health
```

That's your shareable GitHub link! 🎉

## Helpful Git Commands

```bash
# Check status
git status

# View remote URL
git remote -v

# View commit history
git log --oneline
```
