# MindSpace 🧠💚

A full-stack, anonymous peer-to-peer mental health support platform built for students.

## 🌟 Features

- **Anonymous Peer Chat**: Real-time WebSocket chat with automatic matching
- **Student-Counselor Matching**: Connect with trained peer counselors
- **Self-Destructing Messages**: All chats auto-delete after 24 hours
- **SOS Emergency Button**: Quick access to crisis resources
- **Resources Library**: Curated mental health guides and articles
- **100% Privacy**: No email, no tracking, complete anonymity

## 🚀 Tech Stack

- **Frontend**: Next.js 14 (App Router), Tailwind CSS, TypeScript
- **Backend**: Supabase (PostgreSQL, Auth, Realtime)
- **UI**: Lucide React icons, custom gradient designs

## 📦 Quick Start

### 1. Install Dependencies
```bash
npm install
```

### 2. Set Up Supabase
See [SETUP.md](./SETUP.md) for detailed Supabase configuration instructions.

**Quick version:**
1. Create a project at [supabase.com](https://supabase.com)
2. Run the SQL from `supabase/schema.sql` in the SQL Editor
3. Copy your project URL and anon key
4. Create `.env.local`:
   ```env
   NEXT_PUBLIC_SUPABASE_URL=your-project-url
   NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
   ```

### 3. Run Development Server
```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) 🎉

## 🧪 Testing

### Lint
```bash
npm run lint
```

### Build
```bash
npm run build
```

### Chat Test
Open http://localhost:3000/chat in **two different browsers** and click "Find a Peer" on both to test real-time messaging.

## 📁 Project Structure

```
src/
├── app/
│   ├── page.tsx           # Landing page
│   ├── chat/              # Peer-to-peer chat
│   ├── match/             # Counselor matching
│   └── resources/         # Mental health resources
├── components/
│   └── SOSButton.tsx      # Emergency SOS component
└── lib/
    ├── supabase/          # Supabase client/server
    └── utils.ts           # Utility functions

supabase/
└── schema.sql             # Database schema + RLS policies
```

## 🔐 Privacy & Security

- ✅ Anonymous authentication (no email required)
- ✅ Row-Level Security (RLS) on all database tables
- ✅ Self-destructing messages
- ✅ No personal data collection
- ✅ No IP logging

## 🚨 Important Notes

> **This is an MVP**. For production deployment, you would need:
> - Professional moderation system
> - Content filtering and reporting
> - Integration with real emergency services
> - End-to-end encryption
> - Scheduled cleanup jobs for expired messages

## 📝 License

MIT

## 🤝 Contributing

This is a demonstration project. Feel free to fork and adapt for educational purposes.

---

**Remember**: If you or someone you know is in crisis, call 988 (Suicide & Crisis Lifeline) or text HOME to 741741 (Crisis Text Line).
