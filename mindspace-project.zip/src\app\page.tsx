import Link from 'next/link';
import { MessageCircle, Heart, BookOpen, ShieldAlert } from 'lucide-react';
import SOSButton from '@/components/SOSButton';

export default function Home() {
  return (
    <main className="min-h-screen relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-teal-900/20 to-slate-900" />

      {/* Floating orbs for visual depth */}
      <div className="absolute top-20 left-10 w-72 h-72 bg-teal-500/10 rounded-full blur-3xl animate-pulse" />
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl animate-pulse delay-1000" />

      <div className="relative z-10">
        {/* Navigation */}
        <nav className="px-6 py-6 flex justify-between items-center max-w-7xl mx-auto">
          <div className="flex items-center gap-2">
            <Heart className="w-8 h-8 text-teal-400" />
            <span className="text-2xl font-bold bg-gradient-to-r from-teal-400 to-emerald-400 bg-clip-text text-transparent">
              MindSpace
            </span>
          </div>
          <Link
            href="/resources"
            className="px-4 py-2 rounded-lg bg-white/5 hover:bg-white/10 transition-all border border-white/10 backdrop-blur-sm"
          >
            Resources
          </Link>
        </nav>

        {/* Hero Section */}
        <div className="max-w-5xl mx-auto px-6 py-20 text-center">
          <div className="inline-block mb-4 px-4 py-1.5 rounded-full bg-teal-500/10 border border-teal-500/20 text-teal-300 text-sm">
            ✨ 100% Anonymous & Private
          </div>

          <h1 className="text-6xl md:text-7xl font-bold mb-6 leading-tight">
            <span className="bg-gradient-to-r from-white via-teal-100 to-emerald-200 bg-clip-text text-transparent">
              You&apos;re Not Alone
            </span>
          </h1>

          <p className="text-xl text-slate-300 mb-12 max-w-2xl mx-auto leading-relaxed">
            Connect with fellow students who understand. Share, listen, and heal together in a safe, anonymous space.
          </p>

          {/* CTA Cards */}
          <div className="grid md:grid-cols-3 gap-6 mb-16">
            <Link href="/chat" className="group relative">
              <div className="absolute inset-0 bg-gradient-to-r from-teal-500 to-emerald-500 rounded-2xl blur opacity-30 group-hover:opacity-50 transition-opacity" />
              <div className="relative bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-2xl p-8 hover:bg-slate-800/70 transition-all hover:scale-105 hover:border-teal-500/50">
                <MessageCircle className="w-12 h-12 text-teal-400 mb-4 mx-auto" />
                <h3 className="text-xl font-semibold mb-2">Peer Chat</h3>
                <p className="text-slate-400 text-sm">
                  Connect instantly with another student for anonymous support
                </p>
              </div>
            </Link>

            <Link href="/match" className="group relative">
              <div className="absolute inset-0 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-2xl blur opacity-30 group-hover:opacity-50 transition-opacity" />
              <div className="relative bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-2xl p-8 hover:bg-slate-800/70 transition-all hover:scale-105 hover:border-emerald-500/50">
                <Heart className="w-12 h-12 text-emerald-400 mb-4 mx-auto" />
                <h3 className="text-xl font-semibold mb-2">Find a Counselor</h3>
                <p className="text-slate-400 text-sm">
                  Match with trained peer counselors for guided support
                </p>
              </div>
            </Link>

            <Link href="/resources" className="group relative">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-teal-500 rounded-2xl blur opacity-30 group-hover:opacity-50 transition-opacity" />
              <div className="relative bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-2xl p-8 hover:bg-slate-800/70 transition-all hover:scale-105 hover:border-blue-500/50">
                <BookOpen className="w-12 h-12 text-blue-400 mb-4 mx-auto" />
                <h3 className="text-xl font-semibold mb-2">Resources</h3>
                <p className="text-slate-400 text-sm">
                  Browse articles, guides, and helpful mental health tools
                </p>
              </div>
            </Link>
          </div>

          {/* Features */}
          <div className="grid md:grid-cols-3 gap-8 text-left max-w-4xl mx-auto">
            <div className="flex gap-3">
              <div className="mt-1">
                <ShieldAlert className="w-5 h-5 text-teal-400" />
              </div>
              <div>
                <h4 className="font-semibold mb-1">Self-Destructing Messages</h4>
                <p className="text-sm text-slate-400">All conversations automatically delete after 24 hours</p>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="mt-1">
                <MessageCircle className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <h4 className="font-semibold mb-1">Real-Time Support</h4>
                <p className="text-sm text-slate-400">Instant messaging with WebSocket technology</p>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="mt-1">
                <Heart className="w-5 h-5 text-blue-400" />
              </div>
              <div>
                <h4 className="font-semibold mb-1">Zero Data Collection</h4>
                <p className="text-sm text-slate-400">No emails, no tracking, complete anonymity</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Global SOSButton */}
      <SOSButton />
    </main>
  );
}
