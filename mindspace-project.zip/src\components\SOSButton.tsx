'use client';

import { useState } from 'react';
import { AlertCircle, X, Phone } from 'lucide-react';

export default function SOSButton() {
    const [showModal, setShowModal] = useState(false);

    const handleSOS = () => {
        setShowModal(true);
        // In production, this would trigger real emergency services
        // For now, we just show helpful resources
    };

    return (
        <>
            {/* Floating SOS Button */}
            <button
                onClick={handleSOS}
                className="fixed bottom-8 right-8 z-50 group"
                aria-label="Emergency SOS"
            >
                <div className="absolute inset-0 bg-red-500 rounded-full blur-xl opacity-50 group-hover:opacity-75 transition-opacity animate-pulse" />
                <div className="relative bg-gradient-to-br from-red-500 to-red-600 text-white p-4 rounded-full shadow-2xl hover:scale-110 transition-transform">
                    <AlertCircle className="w-8 h-8" />
                </div>
            </button>

            {/* SOS Modal */}
            {showModal && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
                    <div className="relative bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-8 max-w-md w-full border border-slate-700 shadow-2xl">
                        <button
                            onClick={() => setShowModal(false)}
                            className="absolute top-4 right-4 p-2 hover:bg-white/10 rounded-lg transition-colors"
                        >
                            <X className="w-5 h-5" />
                        </button>

                        <div className="flex items-center gap-3 mb-6">
                            <div className="p-3 bg-red-500/20 rounded-full">
                                <AlertCircle className="w-8 h-8 text-red-400" />
                            </div>
                            <h2 className="text-2xl font-bold">Emergency Support</h2>
                        </div>

                        <p className="text-slate-300 mb-6">
                            If you&apos;re in crisis or need immediate help, please reach out to these resources:
                        </p>

                        <div className="space-y-4 mb-6">
                            <a
                                href="tel:988"
                                className="flex items-center gap-3 p-4 bg-slate-700/50 hover:bg-slate-700 rounded-xl transition-colors border border-slate-600"
                            >
                                <Phone className="w-5 h-5 text-teal-400" />
                                <div>
                                    <div className="font-semibold">988 Suicide & Crisis Lifeline</div>
                                    <div className="text-sm text-slate-400">24/7 support available</div>
                                </div>
                            </a>

                            <a
                                href="sms:741741"
                                className="flex items-center gap-3 p-4 bg-slate-700/50 hover:bg-slate-700 rounded-xl transition-colors border border-slate-600"
                            >
                                <Phone className="w-5 h-5 text-emerald-400" />
                                <div>
                                    <div className="font-semibold">Crisis Text Line</div>
                                    <div className="text-sm text-slate-400">Text HOME to 741741</div>
                                </div>
                            </a>
                        </div>

                        <p className="text-sm text-slate-400 text-center">
                            You are valued. You are important. Help is available.
                        </p>
                    </div>
                </div>
            )}
        </>
    );
}
